import os
import glob

footer_starts = [
    '<footer style="color:#fff; padding:40px 0; margin-top:50px;">',
    '<footer style="background:#2874f0; color:#fff; padding:40px 0; margin-top:50px;">'
]

new_footer = """<footer style="background:var(--gray-dark); color:#fff; padding:60px 0; margin-top:50px; font-size:14px;">
        <div class="container" style="display:grid; grid-template-columns: repeat(auto-fit, minmax(200px, 1fr)); gap: 30px; margin-bottom:40px;">
            <div>
                <h3 style="color:var(--gray-light); margin-bottom:15px; font-size:16px;">ABOUT NAYRA</h3>
                <ul style="list-style:none; padding:0; display:flex; flex-direction:column; gap:10px;">
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Contact Us</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">About Us</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Careers</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Nayra Stories</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Corporate Information</a></li>
                </ul>
            </div>
            <div>
                <h3 style="color:var(--gray-light); margin-bottom:15px; font-size:16px;">HELP</h3>
                <ul style="list-style:none; padding:0; display:flex; flex-direction:column; gap:10px;">
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Payments</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Shipping</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Cancellation & Returns</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">FAQ</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Report Infringement</a></li>
                </ul>
            </div>
            <div>
                <h3 style="color:var(--gray-light); margin-bottom:15px; font-size:16px;">CONSUMER POLICY</h3>
                <ul style="list-style:none; padding:0; display:flex; flex-direction:column; gap:10px;">
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Return Policy</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Terms Of Use</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Security</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Privacy</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;">Sitemap</a></li>
                </ul>
            </div>
            <div>
                <h3 style="color:var(--gray-light); margin-bottom:15px; font-size:16px;">SOCIAL</h3>
                <ul style="list-style:none; padding:0; display:flex; flex-direction:column; gap:10px;">
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;"><i class="fab fa-facebook-f" style="width:20px;"></i> Facebook</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;"><i class="fab fa-twitter" style="width:20px;"></i> Twitter</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;"><i class="fab fa-instagram" style="width:20px;"></i> Instagram</a></li>
                    <li><a href="#" style="color:#e2e8f0; transition:color 0.2s;"><i class="fab fa-youtube" style="width:20px;"></i> YouTube</a></li>
                </ul>
            </div>
            <div style="border-left: 1px solid #334155; padding-left: 30px;">
                <h3 style="color:var(--gray-light); margin-bottom:15px; font-size:16px;">SUBSCRIBE</h3>
                <p style="color:#e2e8f0; margin-bottom:15px;">Get updates on the latest trends, deals and more.</p>
                <div style="display:flex; gap:10px;">
                    <input type="email" placeholder="Enter your email" style="padding:10px; flex:1; border:none; border-radius:4px; outline:none; background:#1e293b; color:#fff;" />
                    <button style="background:var(--secondary-color); color:#fff; border:none; padding:10px 15px; border-radius:4px; cursor:pointer; font-weight:bold;">JOIN</button>
                </div>
            </div>
        </div>
        <div style="text-align:center; padding-top:20px; border-top:1px solid #334155;">
            <p>&copy; 2026 Nayra E-commerce. All rights reserved.</p>
        </div>
    </footer>"""

for file_path in glob.glob("*.html"):
    with open(file_path, "r", encoding="utf-8") as f:
        content = f.read()
    
    start_idx = -1
    for starter in footer_starts:
        start_idx = content.find(starter)
        if start_idx != -1:
            # We found the spaces before the tag, actually let's just find the tag
            padding_spaces = content.rfind('\\n', 0, start_idx)
            padding = ""
            if padding_spaces != -1:
                padding = content[padding_spaces+1:start_idx]
            break
            
    if start_idx != -1:
        end_idx = content.find("</footer>", start_idx) + len("</footer>")
        # Ensure we add the padding spaces to the new footer lines so it stays indented if we prepend them
        indented_footer = ("\\n" + padding).join(new_footer.split("\\n"))
        
        new_content = content[:start_idx] + new_footer + content[end_idx:]
        with open(file_path, "w", encoding="utf-8") as f:
            f.write(new_content)
        print(f"Updated {file_path}")
