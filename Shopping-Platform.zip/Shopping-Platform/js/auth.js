import { auth, db } from './firebase.js';

// Signup function
export const signup = async (email, password, fullname) => {
    try {
        const userCredential = await auth.createUserWithEmailAndPassword(email, password);
        const user = userCredential.user;
        
        // Save additional user info in Firestore
        await db.collection('users').doc(user.uid).set({
            fullname: fullname,
            email: email,
            createdAt: firebase.firestore.FieldValue.serverTimestamp()
        });
        
        return { success: true, user };
    } catch (error) {
        return { success: false, message: error.message };
    }
};

// Login function
export const login = async (email, password) => {
    try {
        const userCredential = await auth.signInWithEmailAndPassword(email, password);
        return { success: true, user: userCredential.user };
    } catch (error) {
        return { success: false, message: error.message };
    }
};

// Logout function
export const logout = async () => {
    try {
        await auth.signOut();
        return { success: true };
    } catch (error) {
        return { success: false, message: error.message };
    }
};

// Check Auth State
export const onAuthStateChanged = (callback) => {
    auth.onAuthStateChanged(callback);
};
