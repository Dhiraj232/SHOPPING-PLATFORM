import products from './products.js';
import { addToCart } from './cart.js';
import { auth } from './firebase.js';

// Render products utility
export const renderProducts = (gridElement, productList, currentUser) => {
    if (productList.length === 0) {
        gridElement.style.display = 'none';
        document.getElementById('noResults').style.display = 'block';
        return;
    }

    gridElement.style.display = 'grid';
    document.getElementById('noResults').style.display = 'none';

    gridElement.innerHTML = productList.map(product => `
        <div class="product-card" data-id="${product.id}">
            <a href="product-detail.html?id=${product.id}">
                <img src="${product.image}" alt="${product.title}">
                <div class="product-info">
                    <h3>${product.title}</h3>
                    <div class="rating">
                        ${product.rating} <i class="fa fa-star"></i>
                    </div>
                    <div class="product-price">
                        <span class="current-price">₹${product.price}</span>
                        <span class="old-price">₹${product.oldPrice}</span>
                        <span class="discount">${product.discount}% off</span>
                    </div>
                </div>
            </a>
            <button class="add-to-cart-btn" data-id="${product.id}" style="width:100%; background:#fb641b; color:#fff; border:none; padding:8px; margin-top:10px; cursor:pointer; font-weight:600; border-radius:2px;">
                ADD TO CART
            </button>
        </div>
    `).join('');

    gridElement.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.onclick = async (e) => {
            e.preventDefault();
            const productId = parseInt(btn.getAttribute('data-id'));
            const product = productList.find(p => p.id === productId);
            if (product) {
                await addToCart(currentUser ? currentUser.uid : null, product);
                alert(`${product.title} added to cart!`);
            }
        };
    });
};
