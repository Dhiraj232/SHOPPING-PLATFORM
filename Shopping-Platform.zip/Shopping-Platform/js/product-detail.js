import products from './products.js';
import { addToCart } from './cart.js';
import { auth } from './firebase.js';

const urlParams = new URLSearchParams(window.location.search);
const productId = parseInt(urlParams.get('id'));

const detailImg = document.getElementById('detailImg');
const detailTitle = document.getElementById('detailTitle');
const detailPrice = document.getElementById('detailPrice');
const detailOldPrice = document.getElementById('detailOldPrice');
const detailDiscount = document.getElementById('detailDiscount');
const detailRating = document.getElementById('detailRating');
const detailDescription = document.getElementById('detailDescription');
const breadcrumbCat = document.getElementById('breadcrumbCat');
const breadcrumbTitle = document.getElementById('breadcrumbTitle');
const addToCartBtn = document.getElementById('addToCartBtn');
const buyNowBtn = document.getElementById('buyNowBtn');

let currentUser = null;

const init = () => {
    // Check Auth
    auth.onAuthStateChanged(user => {
        currentUser = user;
    });

    const product = products.find(p => p.id === productId);

    if (product) {
        // Update Title
        document.title = `${product.title} | Nayra`;
        
        // Update UI
        detailImg.src = product.image;
        detailTitle.innerText = product.title;
        detailPrice.innerText = `₹${product.price}`;
        detailOldPrice.innerText = `₹${product.oldPrice}`;
        detailDiscount.innerText = `${product.discount}% off`;
        detailRating.innerHTML = `${product.rating} <i class="fa fa-star"></i>`;
        detailDescription.innerText = product.description || "No description available for this product.";
        
        breadcrumbCat.innerText = product.category;
        breadcrumbTitle.innerText = product.title;

        // Add to Cart
        addToCartBtn.onclick = async () => {
            await addToCart(currentUser ? currentUser.uid : null, product);
            alert(`${product.title} added to cart!`);
        };

        // Buy Now
        buyNowBtn.onclick = async () => {
            await addToCart(currentUser ? currentUser.uid : null, product);
            window.location.href = 'cart.html';
        };

    } else {
        document.body.innerHTML = '<div class="container" style="text-align:center; padding:50px;"><h2>Product not found</h2><a href="index.html">Back to Home</a></div>';
    }
};

window.onload = init;
