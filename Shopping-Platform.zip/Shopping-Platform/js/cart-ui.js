import { auth, db } from './firebase.js';
import { getCart, removeFromCart, updateQuantity, calculateTotals } from './cart.js';

const cartItemsList = document.getElementById('cartItemsList');
const emptyCart = document.getElementById('emptyCart');
const orderSummary = document.getElementById('orderSummary');
const cartFooter = document.getElementById('cartFooter');
const cartCountHeader = document.getElementById('cartCountHeader');
const summaryCount = document.getElementById('summaryCount');
const totalMRP = document.getElementById('totalMRP');
const totalDiscount = document.getElementById('totalDiscount');
const totalAmount = document.getElementById('totalAmount');
const savingAmount = document.getElementById('savingAmount');
const placeOrderBtn = document.getElementById('placeOrderBtn');

let currentUser = null;

const init = () => {
    auth.onAuthStateChanged(async (user) => {
        currentUser = user;
        loadCart();
    });

    placeOrderBtn.onclick = () => {
        if (!currentUser) {
            alert('Please login to place your order.');
            window.location.href = 'login.html?redirect=cart.html';
        } else {
            alert('Order placed successfully! (This is a dummy payment system)');
            // Optionally clear cart in Firestore
        }
    };
};

const loadCart = async () => {
    const userId = currentUser ? currentUser.uid : null;
    const cart = await getCart(userId);

    if (cart.length === 0) {
        cartItemsList.style.display = 'none';
        orderSummary.style.display = 'none';
        cartFooter.style.display = 'none';
        emptyCart.style.display = 'block';
        cartCountHeader.innerText = '0';
    } else {
        emptyCart.style.display = 'none';
        cartItemsList.style.display = 'block';
        orderSummary.style.display = 'block';
        cartFooter.style.display = 'flex';
        
        renderCartItems(cart);
        updateSummary(cart);
    }
};

const renderCartItems = (cart) => {
    cartItemsList.innerHTML = cart.map(item => `
        <div class="cart-item" data-id="${item.id}">
            <img src="${item.image}" alt="${item.title}" class="cart-item-img">
            <div class="cart-item-info">
                <h3 style="font-size:16px; font-weight:400; margin-bottom:8px;">${item.title}</h3>
                <p style="font-size:12px; color:var(--gray-light); margin-bottom:10px;">Category: ${item.category}</p>
                <div class="product-price" style="margin-bottom:15px;">
                    <span class="current-price">₹${item.price}</span>
                    <span class="old-price">₹${item.oldPrice}</span>
                    <span class="discount">${item.discount}% Off</span>
                </div>
                <div class="item-quantity">
                    <button class="qty-btn dec-btn" data-id="${item.id}">-</button>
                    <input type="text" value="${item.quantity}" readonly style="width:40px; text-align:center; border:1px solid #e0e0e0; height:28px;">
                    <button class="qty-btn inc-btn" data-id="${item.id}">+</button>
                </div>
                <button class="remove-btn" data-id="${item.id}">REMOVE</button>
            </div>
            <div style="font-size:14px;">
                Delivery by Tomorrow, Thu | <span style="color:var(--success-color);">Free</span>
            </div>
        </div>
    `).join('');

    // Event Listeners
    cartItemsList.querySelectorAll('.qty-btn').forEach(btn => {
        btn.onclick = async (e) => {
            const productId = parseInt(btn.getAttribute('data-id'));
            const change = btn.classList.contains('inc-btn') ? 1 : -1;
            await updateQuantity(currentUser ? currentUser.uid : null, productId, change);
            loadCart();
        };
    });

    cartItemsList.querySelectorAll('.remove-btn').forEach(btn => {
        btn.onclick = async (e) => {
            const productId = parseInt(btn.getAttribute('data-id'));
            await removeFromCart(currentUser ? currentUser.uid : null, productId);
            loadCart();
        };
    });
};

const updateSummary = (cart) => {
    const totals = calculateTotals(cart);
    
    cartCountHeader.innerText = totals.totalItems;
    summaryCount.innerText = totals.totalItems;
    totalMRP.innerText = `₹${totals.totalMRP}`;
    totalDiscount.innerText = `- ₹${totals.totalDiscount}`;
    totalAmount.innerText = `₹${totals.totalAmount}`;
    savingAmount.innerText = `₹${totals.totalDiscount}`;
};

window.onload = init;
