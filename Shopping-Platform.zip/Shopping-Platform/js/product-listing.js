import products from './products.js';
import { renderProducts } from './utils.js';
import { auth } from './firebase.js';

const productGrid = document.getElementById('productGrid');
const listingTitle = document.getElementById('listingTitle');
const sortDropdown = document.getElementById('sortDropdown');
const catFilters = document.querySelectorAll('.cat-filter');

let filteredProducts = [...products];
let currentUser = null;

// Initialize
const init = () => {
    // Check Auth
    auth.onAuthStateChanged(user => {
        currentUser = user;
        applyFiltersAndSort();
    });

    // Handle Search Param
    const urlParams = new URLSearchParams(window.location.search);
    const searchQuery = urlParams.get('search');

    if (searchQuery) {
        listingTitle.innerText = `Showing results for "${searchQuery}"`;
        filteredProducts = products.filter(p => 
            p.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
            p.category.toLowerCase().includes(searchQuery.toLowerCase())
        );
    }

    // Sort Dropdown Change
    sortDropdown.addEventListener('change', applyFiltersAndSort);

    // Category Filter Change
    catFilters.forEach(chk => {
        chk.addEventListener('change', applyFiltersAndSort);
    });

    applyFiltersAndSort();
};

const applyFiltersAndSort = () => {
    let result = [...filteredProducts];

    // 1. Apply Category Filters
    const selectedCats = Array.from(catFilters)
        .filter(chk => chk.checked)
        .map(chk => chk.value);
    
    if (selectedCats.length > 0) {
        result = result.filter(p => selectedCats.includes(p.category));
    }

    // 2. Apply Sort
    const sortBy = sortDropdown.value;
    if (sortBy === 'low-high') {
        result.sort((a, b) => a.price - b.price);
    } else if (sortBy === 'high-low') {
        result.sort((a, b) => b.price - a.price);
    } else if (sortBy === 'popularity') {
        result.sort((a, b) => b.rating - a.rating);
    }

    // 3. Render
    if (productGrid) {
        renderProducts(productGrid, result, currentUser);
    }
};

window.onload = init;
