import { auth, db } from './firebase.js';

// Get Cart from localStorage or Firestore
export const getCart = async (userId) => {
    if (userId) {
        // Logged-in user: Fetch from Firestore
        const cartDoc = await db.collection('carts').doc(userId).get();
        return cartDoc.exists ? cartDoc.data().items : [];
    } else {
        // Guest user: Fetch from LocalStorage
        const cart = localStorage.getItem('nayra_cart');
        return cart ? JSON.parse(cart) : [];
    }
};

// Add to Cart
export const addToCart = async (userId, product) => {
    let cart = await getCart(userId);
    const existingIndex = cart.findIndex(item => item.id === product.id);

    if (existingIndex > -1) {
        cart[existingIndex].quantity += 1;
    } else {
        cart.push({ ...product, quantity: 1 });
    }

    await saveCart(userId, cart);
    return cart;
};

// Remove from Cart
export const removeFromCart = async (userId, productId) => {
    let cart = await getCart(userId);
    cart = cart.filter(item => item.id !== productId);
    await saveCart(userId, cart);
    return cart;
};

// Update Quantity
export const updateQuantity = async (userId, productId, change) => {
    let cart = await getCart(userId);
    const item = cart.find(i => i.id === productId);
    if (item) {
        item.quantity += change;
        if (item.quantity <= 0) {
            cart = cart.filter(i => i.id !== productId);
        }
    }
    await saveCart(userId, cart);
    return cart;
};

// Save Cart
const saveCart = async (userId, cart) => {
    if (userId) {
        await db.collection('carts').doc(userId).set({ 
            items: cart,
            updatedAt: firebase.firestore.FieldValue.serverTimestamp()
        });
    } else {
        localStorage.setItem('nayra_cart', JSON.stringify(cart));
    }
    
    // Update cart count badge
    updateCartIcon(cart.length);
};

// UI: Update Cart Icon Badge
export const updateCartIcon = (count) => {
    const badge = document.querySelector('.cart-count');
    if (badge) {
        badge.innerText = count;
        badge.style.display = count > 0 ? 'block' : 'none';
    }
};

// Calculate Total Price
export const calculateTotals = (cart) => {
    let totalMRP = 0;
    let totalDiscount = 0;
    let shipping = 0;

    cart.forEach(item => {
        totalMRP += (item.oldPrice || item.price) * item.quantity;
        totalDiscount += ((item.oldPrice || item.price) - item.price) * item.quantity;
    });

    const totalAmount = totalMRP - totalDiscount + shipping;

    return { totalMRP, totalDiscount, totalAmount, totalItems: cart.length };
};
