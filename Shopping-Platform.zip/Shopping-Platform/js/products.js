// Diverse product catalog for Nayra E-commerce
const products = [
    // --- ELECTRONICS (9 items) ---
    {
        id: 1,
        title: "Apple iPhone 14 Pro Max - Space Black, 256GB",
        category: "Electronics",
        price: 139900,
        oldPrice: 149900,
        discount: 6,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1678652317135-c33cc94ae1b7?q=80&w=600&auto=format&fit=crop",
        description: "Dynamic Island, an Always-On display, and the A16 Bionic chip. Capture incredible detail with a 48MP Main camera. Experience the iPhone 14 Pro Max."
    },
    {
        id: 2,
        title: "MacBook Air M2 Chip - Silver (8GB/256GB)",
        category: "Electronics",
        price: 104900,
        oldPrice: 114900,
        discount: 8,
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1611186871348-b1ce696e52c9?q=80&w=600&auto=format&fit=crop",
        description: "Supercharged by the M2 chip. Strikingly thin design with all-day battery life and a stunning 13.6-inch Liquid Retina display."
    },
    {
        id: 3,
        title: "Sony WH-1000XM5 Wireless Noise Cancelling Headphones",
        category: "Electronics",
        price: 29990,
        oldPrice: 34990,
        discount: 14,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1618366712010-f4ae9c647dcb?q=80&w=600&auto=format&fit=crop",
        description: "Industry-leading noise cancellation with two processors and eight microphones for unprecedented listening experiences."
    },
    {
        id: 4,
        title: "Samsung Galaxy S23 Ultra - Phantom Black, 512GB",
        category: "Electronics",
        price: 124999,
        oldPrice: 149999,
        discount: 16,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1675789652575-cf5fc7b16d7a?q=80&w=600&auto=format&fit=crop",
        description: "200MP camera resolution, Epic Nightography, and the powerful Snapdragon 8 Gen 2 processor."
    },
    {
        id: 5,
        title: "Apple Watch Series 8 GPS - Midnight Aluminum Case",
        category: "Electronics",
        price: 41900,
        oldPrice: 45900,
        discount: 8,
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1579586337278-3befd40fd17a?q=80&w=600&auto=format&fit=crop",
        description: "Advanced health sensors and apps to take an ECG, measure heart rate and blood oxygen, and track temperature changes."
    },
    {
        id: 6,
        title: "Logitech MX Master 3S Wireless Mouse",
        category: "Electronics",
        price: 9495,
        oldPrice: 10995,
        discount: 13,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46?q=80&w=600&auto=format&fit=crop",
        description: "Ultrafast MagSpeed scrolling and an 8000 DPI track-on-glass sensor. Quiet Clicks deliver the satisfying feel you love."
    },
    {
        id: 7,
        title: "Keychron K2 V2 Mechanical Keyboard (Blue Switches)",
        category: "Electronics",
        price: 7499,
        oldPrice: 9999,
        discount: 25,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1595225476474-87563907a212?q=80&w=600&auto=format&fit=crop",
        description: "A versatile wireless mechanical keyboard with an 84-key Mac layout and seamless Bluetooth connectivity across 3 devices."
    },
    {
        id: 8,
        title: "Canon EOS R5 Mirrorless Digital Camera Body",
        category: "Electronics",
        price: 319990,
        oldPrice: 339990,
        discount: 5,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1516035069371-29a1b244cc32?q=80&w=600&auto=format&fit=crop",
        description: "45 Megapixel Full-Frame CMOS Sensor, 8K video recording, and state-of-the-art autofocus for professionals."
    },
    {
        id: 9,
        title: "JBL Charge 5 Portable Bluetooth Speaker - Black",
        category: "Electronics",
        price: 13999,
        oldPrice: 17999,
        discount: 22,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?q=80&w=600&auto=format&fit=crop",
        description: "IP67 waterproof and dustproof speaker with 20 hours of playtime and a built-in powerbank."
    },

    // --- FASHION (8 items) ---
    {
        id: 10,
        title: "Men's Classic White Polo T-Shirt",
        category: "Fashion",
        price: 599,
        oldPrice: 1299,
        discount: 53,
        rating: 4.2,
        image: "https://images.unsplash.com/photo-1581655353564-df123a1eb820?q=80&w=600&auto=format&fit=crop",
        description: "Comfortable organic cotton polo t-shirt with a crisp collar. Great for casual office wear and weekends."
    },
    {
        id: 11,
        title: "Women's High-Waisted Mom Jeans",
        category: "Fashion",
        price: 1299,
        oldPrice: 2499,
        discount: 48,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1541099649105-f69ad21f3246?q=80&w=600&auto=format&fit=crop",
        description: "Vintage-inspired mom jeans cut from rigid denim that softens over time. Relaxed fit with a tapered leg."
    },
    {
        id: 12,
        title: "Unisex Oversized Graphic Hoodie - Black",
        category: "Fashion",
        price: 1499,
        oldPrice: 2999,
        discount: 50,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1556821840-3a63f95609a7?q=80&w=600&auto=format&fit=crop",
        description: "Heavyweight fleece hoodie with dropped shoulders and a minimalist front graphic design."
    },
    {
        id: 13,
        title: "Women's Floral Wrap Midi Dress",
        category: "Fashion",
        price: 1899,
        oldPrice: 3999,
        discount: 52,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1612336307429-8a898d10e223?q=80&w=600&auto=format&fit=crop",
        description: "Lightweight georgette midi dress featuring a romantic floral print, v-neckline, and adjustable wrap waist."
    },
    {
        id: 14,
        title: "Men's Navy Blue Two-Piece Suit",
        category: "Fashion",
        price: 4999,
        oldPrice: 9999,
        discount: 50,
        rating: 4.4,
        image: "https://images.unsplash.com/photo-1594938298603-c8148c4dae35?q=80&w=600&auto=format&fit=crop",
        description: "Sharp slim-fit two-piece suit tailored from premium blended fabric. Perfect for weddings and formal events."
    },
    {
        id: 15,
        title: "Classic White Sneakers (Unisex)",
        category: "Fashion",
        price: 1999,
        oldPrice: 3499,
        discount: 42,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1549298916-b41d501d3772?q=80&w=600&auto=format&fit=crop",
        description: "Everyday staple sneakers featuring a clean leather upper, cushioned insole, and durable rubber sole."
    },
    {
        id: 16,
        title: "Women's Leather Handbag - Tan",
        category: "Fashion",
        price: 2499,
        oldPrice: 4999,
        discount: 50,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1584916201218-f4242ceb4809?q=80&w=600&auto=format&fit=crop",
        description: "Spacious tote bag crafted from genuine structured leather. Features multiple interior compartments."
    },
    {
        id: 17,
        title: "Men's Water-Resistant Puffer Jacket",
        category: "Fashion",
        price: 2999,
        oldPrice: 5999,
        discount: 50,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1551028719-00167b16eac5?q=80&w=600&auto=format&fit=crop",
        description: "Insulated puffer jacket designed to keep you warm and dry during harsh winter commutes."
    },

    // --- STATIONERY (8 items) ---
    {
        id: 18,
        title: "Moleskine Classic Hardcover Notebook (Ruled)",
        category: "Stationery",
        price: 1250,
        oldPrice: 1500,
        discount: 16,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1531346878377-a5be20888e57?q=80&w=600&auto=format&fit=crop",
        description: "Legendary notebook with acid-free paper, an elastic closure, and an expandable inner pocket."
    },
    {
        id: 19,
        title: "Lamy Safari Fountain Pen - Matte Black (Fine Nib)",
        category: "Stationery",
        price: 2600,
        oldPrice: 3200,
        discount: 18,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1585060544812-6b45742d762f?q=80&w=600&auto=format&fit=crop",
        description: "Ergonomic ABS plastic fountain pen with a sturdy steel nib and distinctive spring-loaded clip."
    },
    {
        id: 20,
        title: "Pigma Micron Fine Line Pen Set (Pack of 6)",
        category: "Stationery",
        price: 699,
        oldPrice: 899,
        discount: 22,
        rating: 4.9,
        image: "https://images.unsplash.com/photo-1510127034890-ba27508e9f1c?q=80&w=600&auto=format&fit=crop",
        description: "Archival ink pens featuring precise micro-pigment ink that's waterproof and fade-resistant. Ideal for illustration."
    },
    {
        id: 21,
        title: "Faber-Castell Polychromos Colored Pencils (Set of 24)",
        category: "Stationery",
        price: 2850,
        oldPrice: 3500,
        discount: 18,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1520610360662-793db5f8f533?q=80&w=600&auto=format&fit=crop",
        description: "Professional quality colored pencils with exceptionally vibrant pigments and supreme lightfastness."
    },
    {
        id: 22,
        title: "Rhodia DotPad No. 16 - A5 Orange",
        category: "Stationery",
        price: 450,
        oldPrice: 550,
        discount: 18,
        rating: 4.7,
        image: "https://images.unsplash.com/photo-1544810058-005d9c2ebf91?q=80&w=600&auto=format&fit=crop",
        description: "Premium smooth 80g vellum paper featuring a subtle 5mm dot grid, perfect for bullet journaling and sketching."
    },
    {
        id: 23,
        title: "Minimalist Desktop Organizer Kit - Bamboo",
        category: "Stationery",
        price: 1199,
        oldPrice: 1999,
        discount: 40,
        rating: 4.5,
        image: "https://images.unsplash.com/photo-1507851253013-05b6343516ac?q=80&w=600&auto=format&fit=crop",
        description: "Eco-friendly bamboo desktop organizer featuring pen cups, a phone stand, and accessory trays."
    },
    {
        id: 24,
        title: "Post-it Super Sticky Notes - Pastel Colors (5 Pads)",
        category: "Stationery",
        price: 350,
        oldPrice: 450,
        discount: 22,
        rating: 4.8,
        image: "https://images.unsplash.com/photo-1586075010923-2dd4570fb338?q=80&w=600&auto=format&fit=crop",
        description: "Super sticky adhesive lets you stick and re-stick these pastel notes anywhere you need a reminder."
    },
    {
        id: 25,
        title: "Aesthetically Pleasing Metal Paper Clips (Pack of 100)",
        category: "Stationery",
        price: 250,
        oldPrice: 399,
        discount: 37,
        rating: 4.6,
        image: "https://images.unsplash.com/photo-1555365535-ba62bf3ec893?q=80&w=600&auto=format&fit=crop",
        description: "Rose gold and brass finished paper clips that add an elegant touch to your document binding."
    }
];

export default products;
