import { auth, db } from './firebase.js';
import products from './products.js';
import { getCart, updateCartIcon, addToCart } from './cart.js';
import { onAuthStateChanged, logout } from './auth.js';

// Global variables
let currentUser = null;

// Initialize the app
const init = () => {
    // Check auth state
    onAuthStateChanged(async (user) => {
        const authLink = document.getElementById('authLink');
        if (user) {
            currentUser = user;
            // Fetch username from Firestore if available
            const userDoc = await db.collection('users').doc(user.uid).get();
            const username = userDoc.exists ? userDoc.data().fullname : user.email;
            
            authLink.innerHTML = `
                <div class="user-menu" style="position:relative;">
                    <a href="#" id="userProfile" style="background:#fff; color:#2874f0; padding:6px 15px; border-radius:2px; font-weight:600;">
                        ${username.split(' ')[0]} <i class="fa fa-angle-down"></i>
                    </a>
                    <div id="logoutDropdown" style="display:none; position:absolute; top:40px; left:0; background:#fff; color:#212121; width:150px; box-shadow:0 4px 8px rgba(0,0,0,0.1); border-radius:2px;">
                        <ul style="padding:10px 0;">
                            <li><a href="#" id="logoutBtn" style="display:block; padding:8px 15px; font-size:14px;">Logout</a></li>
                        </ul>
                    </div>
                </div>
            `;

            // Toggle logout dropdown
            document.getElementById('userProfile').onclick = (e) => {
                e.preventDefault();
                const dropdown = document.getElementById('logoutDropdown');
                dropdown.style.display = dropdown.style.display === 'none' ? 'block' : 'none';
            };

            // Logout functionality
            document.getElementById('logoutBtn').onclick = async (e) => {
                e.preventDefault();
                await logout();
                window.location.reload();
            };

            // Load user-specific cart
            const cartItems = await getCart(user.uid);
            updateCartIcon(cartItems.length);
        } else {
            currentUser = null;
            authLink.innerHTML = `<a href="login.html" class="login-btn">Login</a>`;
            // Load guest cart
            const cartItems = await getCart(null);
            updateCartIcon(cartItems.length);
        }
    });

    // Render Featured Products (Top 8 for home page)
    const featuredGrid = document.getElementById('featuredGrid');
    if (featuredGrid) {
        const featured = products.slice(0, 8);
        renderProducts(featuredGrid, featured);
    }

    // Search bar functionality
    const searchForm = document.getElementById('searchForm');
    if (searchForm) {
        searchForm.onsubmit = (e) => {
            e.preventDefault();
            const query = document.getElementById('searchInput').value.trim();
            if (query) {
                window.location.href = `product.html?search=${encodeURIComponent(query)}`;
            }
        };
    }
};

// Render products to a grid
export const renderProducts = (gridElement, productList) => {
    gridElement.innerHTML = productList.map(product => `
        <div class="product-card" data-id="${product.id}">
            <a href="product-detail.html?id=${product.id}">
                <img src="${product.image}" alt="${product.title}">
                <div class="product-info">
                    <h3>${product.title}</h3>
                    <div class="rating">
                        ${product.rating} <i class="fa fa-star"></i>
                    </div>
                    <div class="product-price">
                        <span class="current-price">₹${product.price}</span>
                        <span class="old-price">₹${product.oldPrice}</span>
                        <span class="discount">${product.discount}% off</span>
                    </div>
                </div>
            </a>
            <button class="add-to-cart-btn" data-id="${product.id}" style="width:100%; background:#2874f0; color:#fff; border:none; padding:8px; margin-top:10px; cursor:pointer; font-weight:600; border-radius:2px;">
                ADD TO CART
            </button>
        </div>
    `).join('');

    // Add event listeners to "Add to Cart" buttons
    gridElement.querySelectorAll('.add-to-cart-btn').forEach(btn => {
        btn.onclick = async (e) => {
            e.preventDefault();
            const productId = parseInt(e.target.getAttribute('data-id'));
            const product = products.find(p => p.id === productId);
            if (product) {
                await addToCart(currentUser ? currentUser.uid : null, product);
                alert(`${product.title} added to cart!`);
            }
        };
    });
};

// Initialize app when DOM is ready
window.addEventListener('DOMContentLoaded', init);
