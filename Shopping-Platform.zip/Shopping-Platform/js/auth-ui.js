import { signup, login } from './auth.js';

// UI Elements
const loginForm = document.getElementById('loginForm');
const signupForm = document.getElementById('signupForm');
const switchToSignup = document.getElementById('switchToSignup');
const switchToLogin = document.getElementById('switchToLogin');
const sidebarTitle = document.getElementById('sidebarTitle');
const sidebarDesc = document.getElementById('sidebarDesc');

const urlParams = new URLSearchParams(window.location.search);
const redirectUrl = urlParams.get('redirect') || 'index.html';

// Toggle between Login and Signup
switchToSignup.onclick = () => {
    loginForm.style.display = 'none';
    signupForm.style.display = 'block';
    sidebarTitle.innerText = "SignUp";
    sidebarDesc.innerText = "We do not share your personal details with anyone.";
};

switchToLogin.onclick = () => {
    signupForm.style.display = 'none';
    loginForm.style.display = 'block';
    sidebarTitle.innerText = "Login";
    sidebarDesc.innerText = "Get access to your Orders, Wishlist and Recommendations";
};

// Handle Login
loginForm.onsubmit = async (e) => {
    e.preventDefault();
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    const submitBtn = document.getElementById('loginSubmit');

    submitBtn.innerText = 'Loging in...';
    submitBtn.disabled = true;

    const result = await login(email, password);

    if (result.success) {
        window.location.href = redirectUrl;
    } else {
        alert("Login failed: " + result.message);
        submitBtn.innerText = 'Login';
        submitBtn.disabled = false;
    }
};

// Handle Signup
signupForm.onsubmit = async (e) => {
    e.preventDefault();
    const fullName = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    const submitBtn = document.getElementById('signupSubmit');

    submitBtn.innerText = 'Creating account...';
    submitBtn.disabled = true;

    const result = await signup(email, password, fullName);

    if (result.success) {
        alert("Account created successfully!");
        window.location.href = redirectUrl;
    } else {
        alert("Signup failed: " + result.message);
        submitBtn.innerText = 'CONTINUE';
        submitBtn.disabled = false;
    }
};
